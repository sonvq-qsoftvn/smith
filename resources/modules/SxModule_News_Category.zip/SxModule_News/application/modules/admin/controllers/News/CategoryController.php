<?php

class Admin_News_CategoryController extends Zend_Controller_Action
{
	protected $_item;

	public function init() {
		$this->view->menu = array(
			'tab' => 'modules',
			'template' => 'system/__modules.phtml',
			'active' => 'menu-news'
		);

		$config = Zend_Registry::get('config');
		$lngs = $config->system->language;
		$this->view->lngs = $lngs;

		$errortranslations = APPLICATION_ROOT . '/application/var/locale/errors.tmx';
		$this->tmx = new Zend_Translate('tmx', $errortranslations, $_SESSION['System']['lng']);

		$systemAdmin = new Zend_Session_Namespace('SystemAdmin');
		$this->view->admin_tmx = $this->admin_tmx = new Zend_Translate('tmx', APPLICATION_ROOT . '/application/var/locale/admin/news.tmx', $systemAdmin->lng);
		$this->view->admin_menu_tmx = $this->admin_menu_tmx = new Zend_Translate('tmx', APPLICATION_ROOT . '/application/var/locale/admin/menu.tmx', $systemAdmin->lng);
		
		$this->view->adminlngs = $adminlngs = $config->systemadmin->language;
	}

	public function indexAction() {
		SxCms_Acl::requireAcl('news', 'news.index');

		$proxy = new SxModule_News_Category_Proxy();
		$categories = $proxy->getAll(false, $_SESSION['System']['lng'], true, $this->_getParam('page', 1), 25, false);

		$this->view->paginator = $categories;
	}

	public function activateItemAction() {
		$proxy = new SxModule_News_Category_Proxy();
		$category = $proxy->getById((int) $this->_getParam('id'), $_SESSION['System']['lng']);		
		$category->activate();
		
		$cache = Zend_Registry::get('cache');
		$cache->clean(Zend_Cache::CLEANING_MODE_MATCHING_ANY_TAG, array(
			'SxModule_News_Category'
		));

		$flashMessenger = $this->_helper->getHelper('FlashMessenger');
		$flashMessenger->addMessage($this->admin_tmx->_('categorystatusedited'));
		$this->_helper->redirector->gotoSimple('index', 'news_category');
	}

	public function _editablefields() {
		return array('title');
	}

	public function addAction() {
		SxCms_Acl::requireAcl('news', 'news.add');

		$item = new SxModule_News_Category();

		if($this->getRequest()->isPost()) {
			$mapper = new SxModule_News_Category_Mapper();
			$fields = $mapper->fromInput($this->_getAllParams(), $this->_editablefields());
			$data = $mapper->toObject($fields);

			$data->setId((int) $item->getId())
				->setActive( ($this->_getParam('active',0) == 1) ? 1 : 0 );

			$validator = new SxModule_News_Category_Validator();

			if($validator->validate($data)) {
				$data->save();

				$flashMessenger = $this->_helper->getHelper('FlashMessenger');
				$flashMessenger->addMessage($this->admin_tmx->_('categorycreated'));

				$this->_helper->redirector->gotoSimple('index', 'news_category');
			}

			$item = $data;
		}

		$this->view->messages = Sanmax_MessageStack::getInstance('SxModule_News_Category');
		$this->view->item = $item;
	}

	public function editAction() {
		SxCms_Acl::requireAcl('news', 'news.edit');
		
		$proxy = new SxModule_News_Category_Proxy();
		$item = $proxy->getById((int)$this->_getParam('id'), $_SESSION['System']['lng']);
		$item->setTmx($this->tmx);

		if($this->getRequest()->isPost()) {
			$mapper = new SxModule_News_Category_Mapper();
			$fields = $mapper->fromInput($this->_getAllParams(), $this->_editablefields());
			$data = $mapper->toObject($fields, $item);

			$validator = new SxModule_News_Category_Validator();

			if($validator->validate($data)) {
				$data->save();

				$cache = Zend_Registry::get('cache');
				$cache->clean(Zend_Cache::CLEANING_MODE_MATCHING_ANY_TAG, array(
					'SxModule_News_Category'
				));

				$flashMessenger = $this->_helper->getHelper('FlashMessenger');
				$flashMessenger->addMessage($this->admin_tmx->_('categoryedited'));

				$this->_helper->redirector->gotoSimple('index', 'news_category');
			}

			$item = $data;
		}

		$this->view->item = $item;
		$this->view->messages = Sanmax_MessageStack::getInstance('SxModule_News_Category');
	}

	public function deleteAction() {
		SxCms_Acl::requireAcl('news', 'news.delete');

		$proxy = new SxModule_News_Category_Proxy();
		$item = $proxy->getById((int) $this->_getParam('id'), $_SESSION['System']['lng']);

		if($item->getId()) {
			$item->delete();
		}

		$cache = Zend_Registry::get('cache');
		$cache->clean(Zend_Cache::CLEANING_MODE_MATCHING_ANY_TAG, array(
			'SxModule_News_Category'
		));

		$flashMessenger = $this->_helper->getHelper('FlashMessenger');
		$flashMessenger->addMessage($this->admin_tmx->_('newsdeleted'));

		$this->_helper->redirector->gotoSimple('index', 'news_category');
	}
}