<?php

class SxModule_News_Category
{

	protected $_tmx;

	protected $_id;
	protected $_lng;
	protected $_active;
	protected $_title;
	protected $_url;
	protected $_count;

	public function setTmx($tmx) {
		$this->_tmx = $tmx;
		return $this;
	}

	public function getId() {
		return $this->_id;
	}
	public function setId($_id) {
		$this->_id = $_id;
		return $this;
	}

	public function getLng() {
		return $this->_lng;
	}
	public function setLng($lng) {
		$this->_lng = $lng;
		return $this;
	}

	public function getActive() {
		return $this->_active;
	}
	public function setActive($active) {
		$this->_active = $active;
		return $this;
	}

	public function getTitle() {
		return $this->_title;
	}
	public function setTitle($title) {
		$this->_title = $title;
		return $this;
	}

	public function getUrl() {
		return $this->_url;
	}
	public function setUrl($url) {
		$this->_url = $url;
		return $this;
	}
	
	public function getCount(){
		return $this->_count;
	}
	
	public function setCount($_count){
		$this->_count = $_count;
		return $this;
	}

	public function cleanUrl($string){
		$string = htmlentities($string, ENT_QUOTES, 'UTF-8');
		$string = preg_replace('~&([a-z]{1,2})(acute|cedil|circ|grave|lig|orn|ring|slash|th|tilde|uml);~i', '$1', $string);
		$string = html_entity_decode($string, ENT_QUOTES, 'UTF-8');
		$string = preg_replace(array('~[^0-9a-z]~i', '~[ -]+~'), ' ', $string);
		$string = trim($string, ' -');
		$string = str_replace(' ', '-', $string);
		
		return strtolower($string);
	}

	public function _createUrl() {
		return $this->cleanUrl($this->getTitle());
	}


	public function save($params = '*', $tsl_params = '*') {
		$db = Zend_Registry::get('db');
		$mapper = new SxModule_News_Category_Mapper();

		$data = $mapper->toArray($this, 'item');
		$tslData = $mapper->toArray($this, 'tsl');

		if(is_array($params)) {
			$data = $mapper->fromInput($data, $params);
		}

		if(is_array($tsl_params)) {
			$tslData = $mapper->fromInput($tslData, $tsl_params);
		}
		
		if($this->getId()) {			
			$db->update('NewsCategory', $data, 'id = ' . $db->quote( (int) $this->getId() ));
			$db->update('NewsCategoryTsl', $tslData, 'c_id = ' . $db->quote( (int) $this->getId() ) . ' AND lng = ' . $db->quote( $this->getLng() ));
		}
		else {			
			$db->insert('NewsCategory', $data);
			$this->setId($db->lastInsertId());

			$config = Zend_Registry::get('config');
			foreach($config->system->language as $lng => $slng) {
				$tslData['lng'] = $lng;
				$tslData['c_id'] = (int) $this->getId();
				$db->insert('NewsCategoryTsl', $tslData);
			}
		}

		return $this;
	}

	public function delete() {
		$db = Zend_Registry::get('db');
		$db->delete('NewsCategory', 'id = ' . $db->quote( (int) $this->getId()));
		$db->delete('NewsCategoryTsl', 'c_id = ' . $db->quote( (int) $this->getId()));

		return true;
	}

	public function activate() {
		$db = Zend_Registry::get('db');

		if($this->getActive() == 1) {
			$active = array('active' => 0);
			$this->setActive(0);
		}
		else {
			$active = array('active' => 1);
			$this->setActive(1);
		}

		$cache = Zend_Registry::get('cache');
		$cache->clean(Zend_Cache::CLEANING_MODE_MATCHING_ANY_TAG, array(
			'SxModule_News_Category'
		));

		$db->update('NewsCategoryTsl', $active, 'c_id = ' . $db->quote( (int) $this->getId()));

		return true;
	}
}