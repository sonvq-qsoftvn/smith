<?php

class SxModule_News_Validator extends Base_Validator
{
	protected $_namespace = 'SxModule_News';

	public function validate(SxModule_News $object) {
		$this->validateSelected($object->getCategoryId(), 'category_id', 'settings', $this->_namespace);
		$this->validateTextRequired($object->getTitle(), 'title', 'content', $this->_namespace);
		$this->validateText($object->getSummary(), 'summary', 'content', $this->_namespace);
		$this->validateTextRequired($object->getContent(), 'content', 'content', $this->_namespace);
		$msgr = Sanmax_MessageStack::getInstance($this->_namespace);
		if(!$msgr->getNamespaceMessages()) return true;

		return false;
	}
	
	public function validateSelected($value, $name = 'number', $tab = 'common') {
		$validator = new Zend_Validate_GreaterThan(array('min' => 0));
		if($validator->isValid( $value )) {
			return true;
		}

		$msg = Sanmax_MessageStack::getInstance( $this->_namespace );
		$msg->addMessage($name, $validator->getMessages(), $tab);
		return false;
	}
	
}