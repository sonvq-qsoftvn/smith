<?php

class SxModule_News_Category_Proxy extends Base_Proxy
{

	protected $_mapper;

	public function __construct() {
		$this->_mapper = new SxModule_News_Category_Mapper();
	}

	public function getById($cid, $lng, $active = false, $cache = true) {
		if($cache == true) {
			$cacheId = $this->generateCacheId(get_class($this) . '_' . __FUNCTION__, func_get_args());
			$cache = Zend_Registry::get('cache');
			if(true == ($result = $cache->load($cacheId))) return $result;
		}

		$db = Zend_Registry::get('db');
		$select = $db->select()
			->from(array('c' => 'NewsCategory'), array('*'))
			->joinLeft(array('t' => 'NewsCategoryTsl', array('lng', 'title', 'url', 'active')), 'c.id = t.c_id')
			->joinLeft(array('n' => 'News'), array('count' => new Zend_Db_Expr('COUNT(n.c_id)')), 'c.id = n.c_id') 
			->where('c.id = ?', (int) $cid)
			->where('t.lng = ?', $lng);

		if($active) $select->where('t.active = 1');

		$result = $db->fetchRow($select);
		$data = $this->_mapper->toObject(is_array($result) ? $result : array());

		if($cache == true) {
			$cacheTags = $this->generateCacheTags(get_class($this) . '_' . __FUNCTION__, array(
				get_class($this) . '_' . __FUNCTION__ . '_Id' . (int) $cid
			));

			$cache->save($data, $cacheId, $cacheTags);
		}

		return $data;
	}

	public function getAll($active = false, $lng = 'nl', $paginator = true, $pindex = 1, $perpage = 25, $cache = true) {

		if($cache == true) {
			$cacheId = $this->generateCacheId(get_class($this) . '_' . __FUNCTION__, func_get_args());
			$cache = Zend_Registry::get('cache');
			if(true == ($result = $cache->load($cacheId))) return $result;
		}

		$db = Zend_Registry::get('db');
		
		
		$countItems = $db->select()
			->from(array('n' => 'News'), array('COUNT(*)'))
			->where('n.c_id = c.id');
		
		$select = $db->select()
			->from(array('c' => 'NewsCategory'), array('*', 'count' => new Zend_Db_Expr('(' . $countItems . ')')))
			->join(array('t' => 'NewsCategoryTsl', array('lng', 'title', 'url', 'active')), 'c.id = t.c_id')
			->where('t.lng = ?', $lng)
			->order('t.title ASC')
			->group('c.id');
		
				
		if($active) {
			$select->where('t.active = 1');
		}

		if($paginator === true) {
			$adapter = new Base_PaginatorAdapter($select);
			$adapter->setMapper($this->_mapper);

			$data = new Zend_Paginator($adapter);
			$data->setCurrentPageNumber((int)$pindex);
			$data->setItemCountPerPage((int)$perpage);
		}
		else {
			$results = $db->fetchAll($select);
			$data = $this->_mapper->mapAll($results);
		}

		if($cache == true) {
			$cacheTags = $this->generateCacheTags(get_class($this) . '_' . __FUNCTION__);

			$cache->save($data, $cacheId, $cacheTags);
		}

		return $data;
	}
}