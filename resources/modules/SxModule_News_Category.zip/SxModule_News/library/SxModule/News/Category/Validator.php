<?php

class SxModule_News_Category_Validator extends Base_Validator
{
	protected $_namespace = 'SxModule_News_Category';

	public function validate(SxModule_News_Category $object) {
		$this->validateTextRequired($object->getTitle(), 'title', 'content', $this->_namespace);
		$msgr = Sanmax_MessageStack::getInstance($this->_namespace);
		if(!$msgr->getNamespaceMessages()) return true;

		return false;
	}
}