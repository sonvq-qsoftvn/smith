<?php

class SxModule_News_Category_Mapper extends Base_Mapper
{
	public function toObject(Array $import, $instance = false) {
		$fields = array(
			'c_id' => array('type' => 'int', 'set' => 'setId'),
			'active' => array('type' => 'int', 'set' => 'setActive'),
			'lng' => array('type' => 'string', 'set' => 'setLng'),
			'url' => array('type' => 'string', 'set' => 'setUrl'),
			'title' => array('type' => 'string', 'set' => 'setTitle'),
			'count' => array('type' => 'int', 'set' => 'setCount')
		);
		
		$flag = ($instance == false) ? 'new' : 'existing';

		if($instance == false) $instance = new SxModule_News_Category();

		$instance = $this->automapFieldsToObject($import, $fields, $instance, $flag);

		return $instance;
	}

	public function toArray(SxModule_News_Category $item, $type = '*') {
	
		$data = array(
			'id' => $item->getId()
		);

		$tsl = array(
			'lng' => $item->getLng(),
			'title' => $item->getTitle(),
			'url' => $item->_createUrl(),
			'active' => (int)$item->getActive()
		);

		if($type == 'item') return $data;
		elseif($type == 'tsl') return $tsl;

		return array_merge($data, $tsl);
	}
}